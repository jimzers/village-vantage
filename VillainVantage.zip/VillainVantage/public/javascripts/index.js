// Create the search box and link it to the UI element.
function postReportValidation()  {

  var passed = true;
  var errors = '';
  var address = document.forms["postListingForm"]["formattedAddress"].value;

  if(typeof lat === 'undefined' || typeof lng === 'undefined')  {
    alert("Select a location from the list!")
    passed = false;
  } else if(!street_number) {
    passed = false;
    alert("Narrow down location!")
    street_number = false;
  } 

  return passed;
  
}


function initAutocomplete() {
  var addressInput = document.getElementById('formattedAddress');
  var searchBox = new google.maps.places.SearchBox(addressInput);

  searchBox.addListener('places_changed', function() {
        var places = searchBox.getPlaces();

        if (places.length == 0) {
          return;
        }

        places.forEach(function(place) {
            placeId = place.place_id;
            var location = place.geometry.location;
            lat = location.lat();
            lng = location.lng();
            document.forms["postListingForm"]["lat"].value=lat; 
            document.forms["postListingForm"]["lng"].value=lng;  
            var formattedAddress = place.formatted_address;
            document.forms["postListingForm"]["formattedAddress"].value = formattedAddress;

            placeLoop : for(var i = 0; i < place.address_components.length; i++) {
              for(var j = 0; j < place.address_components[j].types.length; j++) {
                if(place.address_components[i].types[j] === 'street_number')  {
                  street_number = true;
                  break placeLoop;
                } else  {
                  street_number = false;
                  break placeLoop;
                }
              }
            }
        });

  });
}