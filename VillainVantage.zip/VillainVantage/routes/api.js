var uuidv4 = require('uuid/v4');
var express = require('express');
var router = express.Router();
// Import Admin SDK
var admin = require("firebase-admin");

// Get a database reference to our blog
var db = admin.database();
var ref = db.ref();
var reportsRef = ref.child("reports");

router.post('/postIncidentReport', function(req, res)	{ 

	// Listing images will be used multiple times, so making variable of data is easier
	var listingImages = req.files['reportImages'];
	var reportId = uuidv4()
	reportsRef.push({
		reportId : reportId,
		crime: req.body.description,
		lat: req.body.lat,
		lng: req.body.lng
	}, function(error) {
		if(error)	{
			// Redirect to some error page
			res.redirect('/')
		}	else {
			// Redirect to correct page
			res.redirect('/')
		}
	})
})

module.exports = router